create view V_$MYSTAT as
  select "SID","STATISTIC#","VALUE" from v$mystat
/

