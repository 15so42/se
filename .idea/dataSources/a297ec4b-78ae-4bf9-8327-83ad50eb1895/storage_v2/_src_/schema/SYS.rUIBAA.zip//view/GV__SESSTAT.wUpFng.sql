create view GV_$SESSTAT as
  select "INST_ID","SID","STATISTIC#","VALUE" from gv$sesstat
/

