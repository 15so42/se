create view V_$RECOVERY_PROGRESS as
  select "START_TIME","TYPE","ITEM","UNITS","SOFAR","TOTAL","TIMESTAMP","COMMENTS" from v$recovery_progress
/

