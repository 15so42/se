create view GV_$_LOCK as
  select "INST_ID","LADDR","KADDR","SADDR","RADDR","LMODE","REQUEST","CTIME","BLOCK" from gv$_lock
/

