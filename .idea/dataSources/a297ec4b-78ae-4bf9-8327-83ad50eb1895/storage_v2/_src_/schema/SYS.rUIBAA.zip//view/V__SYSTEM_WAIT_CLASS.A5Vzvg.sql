create view V_$SYSTEM_WAIT_CLASS as
  select "WAIT_CLASS_ID","WAIT_CLASS#","WAIT_CLASS","TOTAL_WAITS","TIME_WAITED","TOTAL_WAITS_FG","TIME_WAITED_FG" from v$system_wait_class
/

