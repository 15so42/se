create view GV_$DATAGUARD_STATUS as
  select "INST_ID","FACILITY","SEVERITY","DEST_ID","MESSAGE_NUM","ERROR_CODE","CALLOUT","TIMESTAMP","MESSAGE" from gv$dataguard_status
/

