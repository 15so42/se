create view V_$ENCRYPTED_TABLESPACES as
  select "TS#","ENCRYPTIONALG","ENCRYPTEDTS" from v$encrypted_tablespaces
/

