create view GV_$ACCESS as
  select "INST_ID","SID","OWNER","OBJECT","TYPE" from gv$access
/

