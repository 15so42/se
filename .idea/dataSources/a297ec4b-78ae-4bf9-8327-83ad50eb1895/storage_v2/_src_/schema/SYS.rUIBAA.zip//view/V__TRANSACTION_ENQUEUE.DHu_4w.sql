create view V_$TRANSACTION_ENQUEUE as
  select "ADDR","KADDR","SID","TYPE","ID1","ID2","LMODE","REQUEST","CTIME","BLOCK" from v$transaction_enqueue
/

