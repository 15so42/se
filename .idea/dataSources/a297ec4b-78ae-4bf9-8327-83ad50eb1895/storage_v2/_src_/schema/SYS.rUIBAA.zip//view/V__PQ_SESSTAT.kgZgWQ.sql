create view V_$PQ_SESSTAT as
  select "STATISTIC","LAST_QUERY","SESSION_TOTAL" from v$pq_sesstat
/

