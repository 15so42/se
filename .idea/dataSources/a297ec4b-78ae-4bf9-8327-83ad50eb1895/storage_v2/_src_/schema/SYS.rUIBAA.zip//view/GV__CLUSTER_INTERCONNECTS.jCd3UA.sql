create view GV_$CLUSTER_INTERCONNECTS as
  select "INST_ID","NAME","IP_ADDRESS","IS_PUBLIC","SOURCE" from gv$cluster_interconnects
/

