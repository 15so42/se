create view V_$ENQUEUE_STAT as
  select "INST_ID","EQ_TYPE","TOTAL_REQ#","TOTAL_WAIT#","SUCC_REQ#","FAILED_REQ#","CUM_WAIT_TIME" from v$enqueue_stat
/

