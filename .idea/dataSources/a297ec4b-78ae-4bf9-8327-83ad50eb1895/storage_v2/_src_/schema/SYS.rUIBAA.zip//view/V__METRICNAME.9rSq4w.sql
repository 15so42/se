create view V_$METRICNAME as
  select "GROUP_ID","GROUP_NAME","METRIC_ID","METRIC_NAME","METRIC_UNIT" from v$metricname
/

