create view V_$PWFILE_USERS as
  select "USERNAME","SYSDBA","SYSOPER","SYSASM" from v$pwfile_users
/

