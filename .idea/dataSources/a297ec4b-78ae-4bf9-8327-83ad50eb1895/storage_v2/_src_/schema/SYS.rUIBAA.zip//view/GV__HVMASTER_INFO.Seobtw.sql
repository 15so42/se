create view GV_$HVMASTER_INFO as
  select "INST_ID","HV_ID","CURRENT_MASTER","PREVIOUS_MASTER","REMASTER_CNT" from gv$hvmaster_info
/

