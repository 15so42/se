create view V_$OBJECT_PRIVILEGE as
  select "OBJECT_TYPE_NAME","OBJECT_TYPE_ID","PRIVILEGE_ID","PRIVILEGE_NAME" from v$object_privilege
/

