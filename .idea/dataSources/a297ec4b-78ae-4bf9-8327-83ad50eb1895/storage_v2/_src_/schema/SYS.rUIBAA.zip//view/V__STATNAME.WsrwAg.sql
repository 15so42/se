create view V_$STATNAME as
  select "STATISTIC#","NAME","CLASS","STAT_ID" from v$statname
/

