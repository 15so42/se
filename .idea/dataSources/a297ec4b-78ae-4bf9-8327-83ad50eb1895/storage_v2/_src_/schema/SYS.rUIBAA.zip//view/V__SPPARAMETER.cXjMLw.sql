create view V_$SPPARAMETER as
  select "SID","NAME","TYPE","VALUE","DISPLAY_VALUE","ISSPECIFIED","ORDINAL","UPDATE_COMMENT" from v$spparameter
/

