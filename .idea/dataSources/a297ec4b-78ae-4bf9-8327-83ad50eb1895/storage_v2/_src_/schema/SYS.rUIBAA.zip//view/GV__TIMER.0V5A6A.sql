create view GV_$TIMER as
  select "INST_ID","HSECS" from gv$timer
/

