create view V_$ENQUEUE_STATISTICS as
  select "EQ_NAME","EQ_TYPE","REQ_REASON","TOTAL_REQ#","TOTAL_WAIT#","SUCC_REQ#","FAILED_REQ#","CUM_WAIT_TIME","REQ_DESCRIPTION","EVENT#" from v$enqueue_statistics
/

