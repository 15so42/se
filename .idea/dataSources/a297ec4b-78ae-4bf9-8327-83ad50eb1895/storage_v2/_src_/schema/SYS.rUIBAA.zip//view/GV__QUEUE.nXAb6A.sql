create view GV_$QUEUE as
  select "INST_ID","PADDR","TYPE","QUEUED","WAIT","TOTALQ" from gv$queue
/

