create view GV_$SQLTEXT as
  select "INST_ID","ADDRESS","HASH_VALUE","SQL_ID","COMMAND_TYPE","PIECE","SQL_TEXT" from gv$sqltext
/

