create view V_$LOGMNR_STATS as
  select "SESSION_ID","NAME","VALUE" from v$logmnr_stats
/

