create view V_$_LOCK as
  select "LADDR","KADDR","SADDR","RADDR","LMODE","REQUEST","CTIME","BLOCK" from v$_lock
/

