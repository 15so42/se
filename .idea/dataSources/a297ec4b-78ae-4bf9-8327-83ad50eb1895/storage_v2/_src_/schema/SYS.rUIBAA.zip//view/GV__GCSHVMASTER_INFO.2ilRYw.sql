create view GV_$GCSHVMASTER_INFO as
  select "INST_ID","HV_ID","CURRENT_MASTER","PREVIOUS_MASTER","REMASTER_CNT" from gv$gcshvmaster_info
/

