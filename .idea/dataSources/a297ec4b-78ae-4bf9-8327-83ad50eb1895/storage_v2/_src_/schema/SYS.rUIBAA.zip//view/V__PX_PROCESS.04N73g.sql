create view V_$PX_PROCESS as
  select "SERVER_NAME","STATUS","PID","SPID","SID","SERIAL#" from v$px_process
/

